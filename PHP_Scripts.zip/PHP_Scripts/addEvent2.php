<?php
    require_once('connect.php');

    $response = array();
    $response["success"] = false;
    

    if (isset($_POST["name"]) && trim($_POST["name"]) != "" && isset($_POST["user_id"]) && trim($_POST["user_id"]) != ""  && isset($_POST["category_id"]) && trim($_POST["category_id"]) != "" && isset($_POST["venue"]) && trim($_POST["venue"]) != "" && isset($_POST["time"]) && trim($_POST["time"]) != "" && isset($_POST["details"]) && trim($_POST["details"]) != "" && isset($_POST["image"]) && trim($_POST["image"]) != "" && isset($_POST["time_end"]) && trim($_POST["time_end"]) != "" && isset($_POST["price"]) && trim($_POST["price"]) != "" && isset($_POST["attendance"]) && trim($_POST["attendance"]) != "" ){

	    $name = trim($_POST["name"]);
	    $user_id = trim($_POST["user_id"]);    
	    $category_id = trim($_POST["category_id"]);
	    $venue = trim($_POST["venue"]);
	    $eventtime = trim($_POST["time"]);
	    $details = trim($_POST["details"]);
	    $imagePath = trim($_POST["image"]);
	    $eventtime2 = trim($_POST["time_end"]);
	    $price = trim($_POST["price"]);
	    $attendance = trim($_POST["attendance"]);
	    
	    
	    
		$statement = mysqli_prepare($connect, "INSERT INTO events3 
		(name, user_id, category_id, venue, time, details, image, time_end, price, attendance) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
	
	
		mysqli_stmt_bind_param($statement, "ssssssssss", $name, $user_id, $category_id, $venue, $eventtime, $details,$imagePath,$eventtime2,$price,$attendance);
		
	
		
		if (mysqli_stmt_execute($statement)){
		    mysqli_stmt_close($statement);
		    $event_id =  mysqli_insert_id($connect);
		    $event_statement = "SELECT * FROM events3 WHERE event_id = '$event_id';";
	        $event_res = mysqli_query($connect,$event_statement);
	        if (mysqli_num_rows($event_res) ==1) {
	        	$category_statement = "SELECT * FROM category;";
		        $category_res = mysqli_query($connect,$category_statement);
		        $category_list = array();
		        while ($category_row = mysqli_fetch_array($category_res)) {
		            $category_list[$category_row['category_id']] = $category_row['name'];
		        }

		     

		        while ($row = mysqli_fetch_array($event_res)) {
		            $user_id = $row['user_id'];
		            $user_statement = "SELECT * FROM UserComplet WHERE id = '$user_id';";
		            $user_res = mysqli_query($connect,$user_statement);
		            if ($user_row = mysqli_fetch_array($user_res)) {
		                

	        			$response["success"] = true;
	        			$dt = new DateTime($row['time']);
	        			$dt2 = new DateTime($row['time_end']);
			            $newdate = $dt->format('d M h:i A');
		                $newdate2 = $dt2->format('d M h:i A');
		                
		               

		                $msg = array
							(
								'body' 	=> $row['venue'] . ' - ' . $newdate,
								'title'		=> "New Event: " . $row['name'],
								'event_id'=>$row['event_id'],
								'name'=>$row['name'],
				                'time'=>$row['time'],
				                'time_end'=>$row['time_end'],
				                'venue'=>$row['venue'],
				                'details'=>$row['details'],
				                'image'=>$row['image'],
				                'price'=>$row['price'],
				                'attendance'=>$row['attendance'],
				                'category_id'=>$row['category_id'],
				                'category'=>$category_list[$row['category_id']],
								'vibrate'	=> 1,
								'sound'		=> 1
							);
					    //exec('php notifyevent.php '. escapeshellarg(serialize($msg)) .' > /dev/null 2>/dev/null &');
		            }
		        }
	        }
		    
		    

		    
		}
		else {
			mysqli_stmt_close($statement);
		}
	    
    }
    echo json_encode($response);
    mysqli_close($connect);
    $_POST = array();
?>
