<?php
	   	$connect = mysqli_connect("localhost", "id18879190_abcd", "12345678Abcd.", "id18879190_event_planner") or die ("Unable to select database.");
    
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
 $DefaultId = 0;
 
 $ImageData = $_POST['image_data'];
 
 $ImageName = $_POST['image_tag'];
 
 $ImagePath = "upload/$ImageName.jpg";
 
 $ServerURL = $ImagePath;
 
 $InsertSQL = "INSERT INTO events (image_path) values('$ImageName')";
 
 if(mysqli_query($connect, $InsertSQL)){

 file_put_contents($ImagePath,base64_decode($ImageData));

 echo "Your Image Has Been Uploaded.";
 }
 
 mysqli_close($connect);
 }else{
 echo "Please Try Again";
 }






?>