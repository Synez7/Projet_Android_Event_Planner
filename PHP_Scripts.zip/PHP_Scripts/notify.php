<?php
// API access key from Google API's Console
define( 'API_ACCESS_KEY', 'AAAAn6qp4nI:APA91bFw7Z7kVoED77gvfCcm79Xt5th_GvDZxNTp0Lklbmc60kGEsAfhVEbZMYz9TycpbVaH_a5OACPFbRwCGPlty1WVCx1pH-GzZcVwHIF-Tp9IraMyZxxINDmnEbky-8_oRHJBtUiM');


$a = urldecode($_SERVER['PHP_SELF']);
$u = serialize($a[12]);
if ($u >= 1){
	$msg = $u;
	$topic = $msg["usertype_id"];
	$fields = array
	(
		'condition'	=> "'$topic' in topics",
		'data'	=> $msg
	);

	 $headers = array
	 (
	 	'Authorization: key=' . API_ACCESS_KEY,
	 	'Content-Type: application/json'
	 );
	 
	 $ch = curl_init();
	 curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
	 curl_setopt( $ch,CURLOPT_POST, true );
	 curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
	 curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
	 curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
	 curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ));
	 $result = curl_exec($ch );
	 curl_close( $ch );  
}
?>  