<?php
    require_once('connect.php');
    $response = array();
    $response["success"] = false;
    $result = array();

    if (isset($_POST["user_id"]) && trim($_POST["user_id"]) != ""){
        $user_id = trim($_POST["user_id"]);
    $limit = 0;
    if (isset($_POST["limit"])){
        $limit = $_POST["limit"];
        }
        
        $usertype = $_POST["usertype"];
        $creator_id = $_POST["user_id"];
        
        /*$nameP_statement = "SELECT pseudo FROM bookings,UserComplet WHERE active = 1 AND event_id IN(SELECT event_id FROM events3 WHERE user_id = '$creator_id') AND bookings.user_id = UserComplet.id;";
            $nameP_res = mysqli_query($connect,$nameP_statement);
            $nameP_list = array();
            while ($nameP_row = mysqli_fetch_array($nameP_res)) {
                $nameP_list[$nameP_row['pseudo']] = $nameP_row['pseudo'];
                echo  $nameP_list[$nameP_row['pseudo']];
                echo "\n";
            }*/
            
        

        if($usertype == 'User'){
        
        $booking_statement = "SELECT * FROM bookings WHERE (user_id = '$user_id'  AND active = 1) ORDER BY event_id DESC LIMIT 10 OFFSET " . 10*$limit;
        }else{
            $booking_statement = "SELECT * FROM bookings WHERE active = 1 AND event_id IN(SELECT event_id FROM events3 WHERE user_id = '$creator_id') ORDER BY event_id DESC LIMIT 10 OFFSET " . 10*$limit;
        }
        $booking_res = mysqli_query($connect,$booking_statement);
        if (mysqli_num_rows($booking_res) > 0) {
            
            $category_statement = "SELECT * FROM category;";
            $category_res = mysqli_query($connect,$category_statement);
            $category_list = array();
            while ($category_row = mysqli_fetch_array($category_res)) {
                $category_list[$category_row['category_id']] = $category_row['name'];
            }

            $usertype_statement = "SELECT * FROM usertype2;";
            $usertype_res = mysqli_query($connect,$usertype_statement);
            $usertype_list = array();
            while ($usertype_row = mysqli_fetch_array($usertype_res)) {
                $usertype_list[$usertype_row['usertype_id']] = $usertype_row['name'];
            }
            
            
            
    	    while ($booking_row = mysqli_fetch_array($booking_res)) {
    	    	$event_id = $booking_row["event_id"];
                $statement = "SELECT * FROM events3 WHERE event_id = '$event_id';";
                $res = mysqli_query($connect,$statement);
                if (mysqli_num_rows($res) ==1) {
                    if ($row = mysqli_fetch_array($res)) {

                        $user_id = $row['user_id'];
                        $user_statement = "SELECT * FROM UserComplet WHERE id = '$user_id';";
                        $user_res = mysqli_query($connect,$user_statement);
                        if ($user_row = mysqli_fetch_array($user_res)) {

                            array_push($result,
                            array('event_id'=>$row['event_id'],
                            'name'=>$row['name'],
                            'time'=>$row['time'],
                            'venue'=>$row['venue'],
                            'details'=>$row['details'],
                            'usertype'=>$usertype_row['name'],
                            'creator_id'=>$user_row['id'],
                            'creator'=>$user_row['pseudo'],
                            'category_id'=>$row['category_id'],
                            'category'=>$category_list[$row['category_id']],
                            'image'=>$row['image'],
                            'time_end'=>$row['time_end'],
                            'price'=>$row['price'],
                            'attendance'=>$row['attendance'],
                            'nameParticipant'=>$booking_row['nameParticipant'],
                            'confirm'=>$booking_row['confirm'],
                            'confirmDate'=>$booking_row['confirmDate']


                            ));
                            
                            /* array_push($result,
                            array('event_id'=>$booking_row['event_id'],
                            'user_id'=>$booking_row['user_id'],
                            'nameParticipant'=>$booking_row['nameParticipant']
                            
                            ));*/
                        }
                    }
                }
                else{
                    
                    $booking_id = $booking_row["event_id"];
                    $delete_statement = "DELETE FROM bookings WHERE event_id = '$booking_id' AND user_id = '$user_id';";
                    mysqli_query($connect,$delete_statement);
                }
    	    }
    	}
    }
    if (count($result) > 0){
        echo json_encode(array("events"=>$result, "success"=>true),JSON_UNESCAPED_SLASHES);
    }
    else{
        echo json_encode(array("success"=>false));
    }
    
    mysqli_close($connect);
?>