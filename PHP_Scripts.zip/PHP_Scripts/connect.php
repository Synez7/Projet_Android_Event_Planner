<?php
	   	$connect = mysqli_connect("localhost", "id18879190_abcd", "12345678Abcd.", "id18879190_event_planner") or die ("Unable to select database.");

?>