<?php
    require_once('connect.php');

    $response = array();
    $response["success"] = false;

    if (isset($_POST["event_id"]) && trim($_POST["event_id"]) != "" && isset($_POST["name"]) && trim($_POST["name"]) != "" && isset($_POST["user_id"]) && trim($_POST["user_id"]) != ""  && isset($_POST["category_id"]) && trim($_POST["category_id"]) != ""  && isset($_POST["venue"]) && trim($_POST["venue"]) != "" && isset($_POST["time"]) && trim($_POST["time"]) != "" && isset($_POST["time_end"]) && trim($_POST["time_end"]) != ""&& isset($_POST["details"]) && trim($_POST["details"]) != "" && isset($_POST["image"]) && trim($_POST["image"]) != "" && isset($_POST["attendance"]) && trim($_POST["attendance"]) != ""){

	    $event_id = trim($_POST["event_id"]);
	    $name = trim($_POST["name"]);
	    $user_id = trim($_POST["user_id"]);    
	    $category_id = trim($_POST["category_id"]);
	    $venue = trim($_POST["venue"]);
	    $eventtime = trim($_POST["time"]);
	    $eventtime2 = trim($_POST["time_end"]);
	    $details = trim($_POST["details"]);
	    $image = trim($_POST["image"]);
	    $price = trim($_POST["price"]);
	    $attendance = trim($_POST["attendance"]);


	    $old_event_statement = "SELECT * FROM events3 WHERE event_id = '$event_id' AND user_id = '$user_id';";
        $old_event_res = mysqli_query($connect,$old_event_statement);
        if (mysqli_num_rows($old_event_res) ==1) {
        	$statement = "UPDATE events3 SET name = '$name', venue = '$venue', time = '$eventtime', details = '$details', category_id = '$category_id', price = '$price',image = '$image',time_end = '$eventtime2', attendance = '$attendance',updated = now() WHERE event_id = '$event_id' AND user_id = '$user_id';";
			if (mysqli_query($connect,$statement)){
			    
			    $event_statement = "SELECT * FROM events3 WHERE event_id = '$event_id';";
		        $event_res = mysqli_query($connect,$event_statement);
		        if (mysqli_num_rows($event_res) ==1) {
		        	$category_statement = "SELECT * FROM category;";
			        $category_res = mysqli_query($connect,$category_statement);
			        $category_list = array();
			        while ($category_row = mysqli_fetch_array($category_res)) {
			            $category_list[$category_row['category_id']] = $category_row['name'];
			        }

			      

			        if ($row = mysqli_fetch_array($event_res)) {
			            $user_id = $row['user_id'];
			            $user_statement = "SELECT * FROM UserComplet WHERE id = '$user_id';";
			            $user_res = mysqli_query($connect,$user_statement);
			            if ($user_row = mysqli_fetch_array($user_res)) {

		        			$response["success"] = true;
			                $dt = new DateTime($row['time']);
			                $dt2 = new DateTime($row['time_end']);
			                $newdate = $dt->format('d M h:i A');
			                $newdate2 = $dt2->format('d M h:i A');
			                $msg = array
								(
									'body' 	=> $row['venue'] . ' - ' . $newdate,
									'title'		=> "Updated Event: " . $row['name'],
									'event_id'=>$row['event_id'],
									'name'=>$row['name'],
					                'time'=>$row['time'],
					                'venue'=>$row['venue'],
					                'details'=>$row['details'],
					                'creator_id'=>$row['user_id'],
					                'creator'=>$user_row['pseudo'],
					                'category_id'=>$row['category_id'],
					                'category'=>$category_list[$row['category_id']],
					                'image'=>$row['image'],
					                'time_end'=>$row['time_end'],
					                'price'=>$row['price'],
					                'attendance'=>$row['attendance'],
									'vibrate'	=> 1,
									'sound'		=> 1
								);
						    //exec('php notifyevent.php '. escapeshellarg(serialize($msg)) .' > /dev/null 2>/dev/null &');
			            }
			        }
		        }
			}
        }
    }
    echo json_encode($response,JSON_UNESCAPED_SLASHES);
    mysqli_close($connect);
    $_POST = array();
?>
