<?php
   	$connect = mysqli_connect("localhost", "id18879190_abcd", "12345678Abcd.", "id18879190_event_planner") or die ("Unable to select database.");
   	

    
    if ( isset($_POST["email"])  && isset($_POST["pseudo"])  && isset($_POST["motdepasse"]) && isset($_POST["usertype_id"]) && trim($_POST["usertype_id"]) != ""){

    $email = trim($_POST['email']);
   	$pseudo = trim($_POST['pseudo']);
   	//$nom = trim($_POST['nom']);
   	//$prenom = trim($_POST['prenom']);
    $motdepasse = $_POST['motdepasse'];
    $usertype_id = trim($_POST["usertype_id"]);

    }
    

    
    $check_email = mysqli_query($connect, "SELECT email FROM UserComplet where email = '$email'");
    $check_pseudo = mysqli_query($connect, "SELECT pseudo FROM UserComplet where pseudo = '$pseudo'");

    
    $query = "INSERT INTO UserComplet (email,pseudo,motdepasse,usertype_id) VALUES (?, ?, ?,?)";
    $stmt = mysqli_prepare($connect, $query) or die(mysqli_error($connect));
    $stmt->bind_param('ssss', $email, $pseudo, $motdepasse,$usertype_id);
    
      if(mysqli_num_rows($check_email) == 1 || mysqli_num_rows($check_pseudo) == 1){
        
      echo "Adresse email et/ou pseudo déjà utilisé !";
      
    }
    else{
        
          $stmt->execute();
          $stmt->close();
          
          echo "Nouvel utilisateur enregistré dans la base !";

          
        
    }
    
  

       
       mysqli_close($connect);


        


    ?>










                
