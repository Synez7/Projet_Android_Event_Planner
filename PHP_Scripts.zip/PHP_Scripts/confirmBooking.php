<?php
    require_once('connect.php');

    $response = array();
    $response["success"] = false;
    
    $date = new DateTime();
	$date->setTimezone(new DateTimeZone('+0200')); //GMT
	$currentDate = $date->format('Y-m-d H:i:s');


    if (isset($_POST["event_id"]) && trim($_POST["event_id"]) != "" && isset($_POST["user_id"]) && trim($_POST["user_id"]) != "" && isset($_POST["nameParticipant"]) && trim($_POST["nameParticipant"]) != ""){

	    $event_id = trim($_POST["event_id"]);
	    $user_id = trim($_POST["user_id"]);
	    $participant = trim($_POST["nameParticipant"]);
	    $val = 1;
	 
	    $event_statement = "SELECT * FROM events3 WHERE event_id = '$event_id';";
        $event_res = mysqli_query($connect,$event_statement);
	    $usertype_list = array();
		 while ($usertype_row = mysqli_fetch_array($event_res)) {
		      $usertype_list[$usertype_row['event_id']] = $usertype_row['attendance'];
		      $attendance =  $usertype_row['attendance'];
		     
		 }
	    
	    
	    $book_statement = "UPDATE bookings SET confirm = '$val', confirmDate = '$currentDate' WHERE event_id = '$event_id' AND user_id != '$user_id' AND nameParticipant = '$participant';";
        if (mysqli_query($connect,$book_statement)) {
        	//$statement = "DELETE FROM events SET name = '$name', venue = '$venue', time = '$eventtime', details = '$details'";
			//$bookmark_statement = "DELETE FROM bookmarks WHERE event_id = '$event_id';";
            //mysqli_query($connect,$bookmark_statement);
            $response["success"] = true;
        }
        
         $a_statement = "SELECT * FROM bookings WHERE event_id = '$event_id' AND confirm = 1;";
         $a_res = mysqli_query($connect,$a_statement);
         if (mysqli_num_rows($a_res) > $attendance) {
            $response["success"] = false;
            
         }
        
        
    }
    echo json_encode($response);
    mysqli_close($connect);
    $_POST = array();
?>
