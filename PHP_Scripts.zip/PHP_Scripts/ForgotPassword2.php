<?php

$connect = mysqli_connect("localhost", "id18879190_abcd", "12345678Abcd.", "id18879190_event_planner") or die ("Unable to select database.");


    $pseudo = trim($_POST["pseudo"]);
    
    $query = "SELECT pseudo FROM UserComplet where pseudo='$pseudo'";
    $query2 = "SELECT motdepasse FROM UserComplet where pseudo='$pseudo'";

    
    $result = mysqli_query($connect,$query);
    $result2 = mysqli_query($connect,$query2);
    $count = mysqli_num_rows($result);
    
    if($count == 1){
        //echo "Email trouvé dans la base utilisateur, le mot de passe retrouvé se trouve dans la zone de saisie de l'email";
        //$row = mysql_fetch_row($query2);
        $mdp = mysqli_fetch_assoc($result2);

        echo $mdp["motdepasse"];
    }
    else{
    echo "Impossible de retrouver le mot de passe";
    }
    mysqli_close($connect);
    ?>