<?php
    require_once('connect.php');
     $response = array();
    $response["success"] = false;  

    if (isset($_POST["oldPassword"]) && isset($_POST["newPassword"]) && isset($_POST["email"]) && trim($_POST["email"]) != ""){
        
        $email = trim($_POST["email"]);
        $oldPassword = $_POST["oldPassword"];
        $newPassword = $_POST["newPassword"];

        $statement = "SELECT * FROM UserComplet WHERE email = '$email'";
        $res = mysqli_query($connect,$statement);
        if (mysqli_num_rows($res) == 1) {
            if ($row = mysqli_fetch_array($res)) {
                if (strcmp($oldPassword,$row["motdepasse"]) == 0) {
                    //$newpashash = password_hash($newPassword, PASSWORD_DEFAULT);
                    $update_statement = "UPDATE UserComplet SET motdepasse = '$newPassword' WHERE email = '$email'";
                    if (mysqli_query($connect, $update_statement)){
                        $response["success"] = true;  
                    }
                    else{
                        $response["success"] = false;  
                    }
                }
            }
        }
    }

   
    
    echo json_encode($response);
    mysqli_close($connect);
    $_POST = array();
?>
