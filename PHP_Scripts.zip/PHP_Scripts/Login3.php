<?php
    require_once('connect.php');
    
    if(isset($_POST["pseudo"]) && isset($_POST["motdepasse"])){
        $pseudo = trim($_POST["pseudo"]);
        $motdepasse = $_POST["motdepasse"];

    }
   
    

    $response = array();
    $response["success"] = false;
    
    
    $statement = mysqli_prepare($connect, "SELECT * FROM UserComplet WHERE pseudo = ?");
    mysqli_stmt_bind_param($statement, "s", $pseudo);
    mysqli_stmt_execute($statement);
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $colUserID, $colEmail, $colPseudo, $colPassword, $colUserType);
    
    
    while(mysqli_stmt_fetch($statement)){
                if (strcmp($motdepasse, $colPassword) == 0) {
                    $response["success"] = true;
                    $response["id"] = $colUserID;
                    $response["email"] = $colEmail;
                    $response["pseudo"] = $colPseudo;
                    $response["usertype_id"] = $colUserType;
                    $usertype_sql = "SELECT name FROM usertype2 WHERE usertype_id = '$colUserType'";
                    $usertype_res = mysqli_query($connect, $usertype_sql);
                    
                    if (mysqli_num_rows($usertype_res) == 1) {
                        if($row = mysqli_fetch_array($usertype_res, MYSQLI_ASSOC)) {
                            $usertype_sql = "SELECT name FROM usertype2 WHERE usertype_id = '$colUserType'";
                            $usertype_res = mysqli_query($connect, $usertype_sql);
                            
                            if (mysqli_num_rows($usertype_res) == 1) {
                                if($usertype_row = mysqli_fetch_array($usertype_res, MYSQLI_ASSOC)) {
                                    $response["usertype"] = $usertype_row["name"];
                                }
                            }
                       }
                   }

                    //$response["pseudo"] = $colPseudo;

                    $cat_stat = "SELECT * FROM usertype2";
                    $cat_res = mysqli_query($connect, $cat_stat);
                   $response["usertypes"] = mysqli_num_rows($cat_res);



                }
            }
        
    
    echo json_encode($response);    
    mysqli_close($connect);
?>
